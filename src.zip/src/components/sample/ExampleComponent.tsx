export default function ExampleComponent() {
  return <h1>Hello, world!</h1>
}
