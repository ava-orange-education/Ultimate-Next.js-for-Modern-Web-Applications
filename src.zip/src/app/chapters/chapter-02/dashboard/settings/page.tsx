import { BackToChapterHome } from '../../BackToChapterHome'

export default function DashboardSettings() {
  return (
    <div>
      <BackToChapterHome />
      <h1>Dashboard Settings</h1>
    </div>
  )
}
