import { BackToChapterHome } from '../BackToChapterHome'

export default function AboutPage() {
  return (
    <div>
      <BackToChapterHome />
      <h1>About Page</h1>
    </div>
  )
}
