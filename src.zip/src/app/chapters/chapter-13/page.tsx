export default function HomePage() {
  return (
    <div>
      <h1>Welcome to the Next.js  Real-World App</h1>
      <p>Explore the car catalog, read blog posts, or sign in to access your dashboard.</p>
    </div>
  );
}