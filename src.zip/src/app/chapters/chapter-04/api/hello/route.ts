export async function GET() {
  return Response.json({ message: 'Hello from App Router!' });
}
