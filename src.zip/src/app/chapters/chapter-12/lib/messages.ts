import en from '../locales/en/common.json';
import fr from '../locales/fr/common.json';
export default { en, fr };